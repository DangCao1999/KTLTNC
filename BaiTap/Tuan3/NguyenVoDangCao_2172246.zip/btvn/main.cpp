#include <iostream>
#include "menu.cpp"
using namespace std;

int main()
{
    Menu menu = Menu();
    menu.enterSelect();

    system ("pause");
    return 0;
}